Readme for Highwa 202!!!!

1. Turn on the hotspot of android device.
2. Connect the laptop to android device WiFi.
3. Excecute the Java SerialComm , which will start java server and serial communication.
4. Connect the laptop to FPGA.
5. Turn on the vivado and burn the bitstream on FPGA.
6. Start the application 'Highway 202' on Android.

GO PLAY !!!!!

Copyright Malingarya, Sachin, Sukrut, Karthik  