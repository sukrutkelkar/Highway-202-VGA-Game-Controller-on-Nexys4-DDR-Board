/**
 * Serial_send.java
 * 
 * Description:
 * This class of java accepts the data from Serial.java
 * The data is then sent on serial port which will act as an UART transmitter
 * 
 * Settings of UART transmission is kept static
 * Baud rate : 115200
 * Data : 8 bit
 * parity: No Parity
 * Stop bits: 1
 * 
 */


import java.io.PrintWriter;
import java.util.Scanner;

import com.fazecast.jSerialComm.SerialPort;


public class Serial_send {
	
	public void Send_data(String player_name)
	{
		final String p_name = player_name;
	
		Thread t_serial = new Thread(new Runnable(){
	    // determine which serial port to use
		public void run(){
			
			
		    SerialPort ports[] = SerialPort.getCommPorts();
		
		    // open and configure the port
		 //   SerialPort port = ports[chosenPort - 1];
		    SerialPort port = ports[0];
		    if(port.openPort()) {
		            System.out.println("Successfully opened the port.");
		    } else {
		            System.out.println("the port is busy.");
		            return;
		    }
		    port.setComPortParameters(115200, 8, 1, SerialPort.NO_PARITY);
		    port.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 0, 0);
		   
		
		    	PrintWriter output = new PrintWriter(port.getOutputStream());
		    
		    		System.out.println(p_name);
		    		output.print(p_name);
		    		output.flush();
		
		    		port.closePort();
		}
		});
		
		t_serial.start();
	
	}

}
