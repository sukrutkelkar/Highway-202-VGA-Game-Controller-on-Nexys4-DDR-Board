/**
 *Serial.java
 *
 * Description:
 * This is socket program to read data on TCP/IP network.
 * This program accepts a byte of data on its local WiFi network.
 * This program also instantiate another class of Java 'Serial_Send'.
 * The accepted data is passed to this class, which sends data on serial port.
 * The serial port is connected to Nexys4 FPGA   
 * 
 */

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JSlider;

import com.fazecast.jSerialComm.*;
 
public class Serial {
	
	static String player_name = "";
	static int j = 0;
	
 
        public static void main(String[] args) {
        	
            	
        	
    		Thread t = new Thread(new Runnable() {
    			
    			public void run(){
    				
    			
    			
    			try{
    				
    				ServerSocket ss = new ServerSocket(4444);
    				System.out.println("Running......");

                                while(true)
                                {
                                	
                                	Serial_send serialSend = new Serial_send();
    	                                Socket s1 = ss.accept();
    									
    	                                DataInputStream dis = new DataInputStream(s1.getInputStream());
    	                                    									
    	                               player_name = dis.readUTF();
    	
    	                                dis.close();
    	                                s1.close();
    	                               serialSend.Send_data(player_name);
    	                              
                                }
    				
    			}catch (IOException e)
    			{
    				e.printStackTrace();
    			}
    			}
    			
    			
    			
    		});
    		t.start();
    	

        	
        	
        	
        }

}