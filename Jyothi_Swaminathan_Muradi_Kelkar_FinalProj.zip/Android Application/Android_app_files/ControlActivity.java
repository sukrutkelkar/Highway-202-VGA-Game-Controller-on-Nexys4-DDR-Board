package ece540finalproject.highway202;

/**
 // Control activity : Highway 202 Application
 // This activity contains four image buttons for the movement of icon on VGA screen
 // There are two more image buttons as 'Yes' or 'No' for the control over game
 */




import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ControlActivity extends AppCompatActivity {

    ImageButton mLeft; //Left movement
    ImageButton mRight; //Right movement
    ImageButton mFwd; //Forward movement
    ImageButton mBack; //Back movement
    ImageButton mYes; // Yes button
    ImageButton mNo; //No button
    String player_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Taking string intent 'player_name' from main activity
        player_name = getIntent().getStringExtra(MainActivity.PLAYER_NAME);
        setTitle("Watch your steps "+player_name+" !!!");


        mLeft = (ImageButton)findViewById(R.id.leftButton);
        mLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("1"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                           // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread

                Toast.makeText(getApplicationContext(), "Move left", Toast.LENGTH_SHORT).show();

            }
        });

        mRight = (ImageButton)findViewById(R.id.rightButton);
        mRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("2"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread

                Toast.makeText(getApplicationContext(), "Move Right", Toast.LENGTH_SHORT).show();

            }
        });

        mFwd = (ImageButton)findViewById(R.id.upButton);
        mFwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("4"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread


                Toast.makeText(getApplicationContext(), "Move Forward", Toast.LENGTH_SHORT).show();

            }
        });

        mBack = (ImageButton)findViewById(R.id.downButton);
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("8"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread

                Toast.makeText(getApplicationContext(), "Move Back", Toast.LENGTH_SHORT).show();

            }
        });

        mYes = (ImageButton)findViewById(R.id.continueButton);
        mYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("3"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread

                Toast.makeText(getApplicationContext(), "Yes", Toast.LENGTH_SHORT).show();

            }
        });

        mNo = (ImageButton)findViewById(R.id.exitButton);
        mNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Thread t = new Thread(new Runnable() {                      //Starting the thread which sends data to wifi module
                    @Override
                    public void run() {
                        try {
                            Socket s = new Socket("192.168.43.192",4444);         //Port number and IP are kept static
                            DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());

                            dataOutputStream.writeUTF("7"); //Writing the player name to Outputstream
                            dataOutputStream.flush();   //Flush function performs the action of sending the data to server
                            dataOutputStream.close();
                            s.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            // tv.setText("ERROR");
                        }
                    }
                });
                t.start();      //Starting the thread

                Toast.makeText(getApplicationContext(), "No", Toast.LENGTH_SHORT).show();

            }
        });










    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_control, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
